"""Native tactile manufacturing workflow; no browser required."""
import copy
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk
from touch_ui import TouchCombo, messagebox
from manufacturing import ManufacturingStore, now, serial_keys, assembly_validation, final_validation, data_dir, cell_line
from manufacturing_excel import export_local, sync_nas, MergeConflict
from dolibarr_client import ApiError, config_path

class ManufacturingUI:
    def __init__(self,app):
        self.app=app;self.store=ManufacturingStore();self.current=None;self.vars={};self.autosave=None;self.busy=False
    def flush(self):
        if self.autosave:
            self.app.root.after_cancel(self.autosave);self.autosave=None
        if self.current and self.vars:
            self.save(silent=True)
    def field_values(self):return {k:v.get().strip() for k,v in self.vars.items()}
    def save(self,silent=False):
        if not self.current or self.busy:return True
        try:
            job=self.store.get(self.current)
            values=self.field_values()
            if all(str(job['fields'].get(k,''))==v for k,v in values.items()):return True
            job['fields'].update(values);self.store.save(job,self.app.session.user or 'local')
            if hasattr(self,'status') and self.status.winfo_exists():self.status.config(text='Brouillon enregistré sur le Pi · '+now()[11:19],fg='#267044')
            return True
        except Exception as e:
            if hasattr(self,'status') and self.status.winfo_exists():self.status.config(text=str(e),fg='#a02020')
            if not silent:messagebox.showerror('Enregistrement',str(e),parent=self.app.root)
            return False
    def changed(self,*args):
        if self.autosave:self.app.root.after_cancel(self.autosave)
        self.autosave=self.app.root.after(400,self.save_scheduled)
    def save_scheduled(self):self.autosave=None;self.save(silent=True)
    def reset(self):
        if not self.save():return False
        self.app.keyboard.close();self.current=None;self.vars={}
        for w in self.app.body.winfo_children():w.destroy()
        return True
    def run(self,action,done,failed=None):
        if self.busy:return
        self.busy=True
        self.app.keyboard.close()
        disabled=[]
        def disable_tree(w):
            for child in w.winfo_children():
                try:
                    state=child.cget('state');child.configure(state='disabled');disabled.append((child,state))
                except tk.TclError:pass
                disable_tree(child)
        disable_tree(self.app.body)
        for b in self.app.tabs:b.config(state='disabled')
        self.app.logout_button.config(state='disabled')
        result=queue.Queue()
        def worker():
            try:result.put((True,action()))
            except Exception as e:result.put((False,e))
        def poll():
            try:ok,value=result.get_nowait()
            except queue.Empty:self.app.root.after(100,poll);return
            self.busy=False
            for widget,state in disabled:
                if widget.winfo_exists():widget.configure(state=state)
            for b in self.app.tabs:b.config(state='normal')
            self.app.logout_button.config(state='normal')
            if ok:
                try:done(value)
                except Exception as e:messagebox.showerror('Fabrication',str(e),parent=self.app.root)
            else:
                if failed:failed(value)
                messagebox.showerror('Fabrication',str(value),parent=self.app.root)
        threading.Thread(target=worker,daemon=True).start();self.app.root.after(100,poll)
    def request(self,route,payload=None):
        client=self.app.client
        if not client or not self.app.personal:raise ValueError('Associez votre compte personnel Dolibarr pour la fabrication.')
        return client._request('atelierborne/manufacturing/'+route,method='POST' if payload is not None else 'GET',payload=payload)
    def home(self,tests=False):
        if not self.reset():return
        a=self.app;a.label(a.body,'Calibrage / Mise en boîte' if tests else 'Fabrication',True)
        bar=tk.Frame(a.body,bg='#f4f6fa');bar.pack(fill='x')
        if not tests:
            a.button(bar,'Nouvel OF',self.new_order).pack(side='left',padx=3)
            a.button(bar,'OF Dolibarr',self.orders).pack(side='left',padx=3)
        a.button(bar,'Excel / NAS',self.exports).pack(side='left',padx=3)
        a.label(a.body,'Scans et mesures sauvegardés sur le Pi. Stock modifié uniquement à la validation finale.')
        if self.store.pending('__create__'):a.button(a.body,'Reprendre la création d’OF en attente',lambda:self.submit(self.store.pending('__create__'))).pack(anchor='w')
        frame=a.listing();jobs=self.store.all()
        if not jobs:a.label(frame,'Aucune fabrication commencée.')
        for j in jobs:
            if tests and j['stage'] not in ('Calibrage','Mise en boîte'):continue
            f=a.card(frame);a.label(f,f"{j['fields'].get('battery_serial') or 'Numéro de batterie à scanner'} · {j['order']['model']} · {j['stage']}")
            a.button(f,'Ouvrir',lambda jid=j['id']:self.edit(jid)).pack(anchor='e')
            if j['stage']!='Terminée' and not self.store.pending(j['id']):
                a.button(f,'Supprimer du Pi',lambda jid=j['id']:self.delete_local(jid,tests)).pack(anchor='e',pady=(4,0))
    def new_order(self):
        a=self.app;w=a.dialog('Créer un OF pour une batterie')
        a.label(w,'Produit fabriqué / nomenclature active')
        choice=tk.StringVar();combo=TouchCombo(w,textvariable=choice,state='disabled');combo.pack(fill='x')
        a.label(w,'Sélectionnez le produit fabriqué. La référence BOM reste gérée automatiquement.')
        mapping={}
        def loaded(rows):
            mapping.clear();values=[]
            for row in rows:
                product=(row.get('product_label') or row.get('product_ref') or 'Produit sans nom').strip()
                display=product+' · '+str(row.get('product_ref') or '')
                if display in mapping:display+=' · '+str(row.get('bom_ref') or '')
                mapping[display]=str(row.get('bom_ref') or '');values.append(display)
            combo['values']=values;combo.configure(state='readonly')
            if values:combo.set(values[0])
            else:a.label(w,'Aucune nomenclature de fabrication active disponible.')
        self.run(lambda:self.app.client.paginate('atelierborne/manufacturing/boms') if self.app.client and self.app.personal else self.request('boms'),loaded)
        def create():
            bom_ref=mapping.get(choice.get(),'')
            if not bom_ref:
                messagebox.showwarning('Nomenclature','Sélectionnez un produit fabriqué.',parent=self.app.root);return
            op=self.store.enqueue('__create__','create',{'bom_ref':bom_ref});a.keyboard.close();w.destroy();self.submit(op)
        a.button(w,'Créer l’OF',create).pack(pady=12)
    def orders(self):
        if not self.reset():return
        a=self.app;a.label(a.body,'Ordres ouverts — une batterie par OF',True)
        a.button(a.body,'Retour',self.home).pack(anchor='w')
        def done(rows):
            frame=a.listing()
            if not rows:a.label(frame,'Aucun OF ouvert pour une quantité de 1.')
            local={str(j['order'].get('id')):j for j in self.store.all()}
            for r in rows:
                lj=local.get(str(r['id']));serial=(lj or {}).get('fields',{}).get('battery_serial','') if lj else ''
                product=r.get('product_label') or r.get('product_ref') or r.get('label') or 'Produit fabriqué'
                f=a.card(frame);a.label(f,(serial or 'Numéro de batterie à scanner')+' · '+str(product))
                a.button(f,'Préparer',lambda ident=r['id']:self.load_order(ident)).pack(anchor='e')
                if int(r.get('status',-1)) in (0,1,2):
                    a.button(f,'Supprimer dans Dolibarr',lambda ident=r['id'],ref=r['ref']:self.delete_remote(ident,ref)).pack(anchor='e',pady=(4,0))
        self.run(lambda:a.client.paginate('atelierborne/manufacturing/orders') if a.client and a.personal else self.request('orders'),done)
    def load_order(self,ident):
        actor=self.app.session.user
        self.run(lambda:self.request('orders/'+str(ident)),lambda order:self.edit(self.store.create(order,actor)['id']))
    def submit(self,op):
        actor=self.app.session.user
        def done(response):
            job=self.store.complete(op,response,actor)
            self.current=None;self.vars={};self.edit(job['id'])
            try:export_local(self.store,job['order']['model'])
            except Exception as e:messagebox.showwarning('Export Excel en attente',str(e),parent=self.app.root)
        def failed(error):
            if isinstance(error,ApiError) and error.code in (400,401,403,404,409):
                self.store.reject(op,error)
                if op['job']!='__create__':
                    self.current=None;self.vars={};self.edit(op['job'])
        self.run(lambda:self.request(op['kind'],op['payload']),done,failed)
    def next_entry(self,event):
        w=event.widget.tk_focusNext();start=w
        while w is not event.widget:
            if isinstance(w,(tk.Entry,ttk.Entry)) and str(w.cget('state'))=='normal':
                w.focus_set();return 'break'
            w=w.tk_focusNext()
            if w is start:break
        return 'break'
    def input(self,parent,label,key,value='',width=24,scan=False,readonly=False):
        a=self.app;row=tk.Frame(parent,bg='white');row.pack(fill='x',pady=3)
        tk.Label(row,text=label,bg='white',anchor='w',width=24,font=('DejaVu Sans',18)).pack(side='left')
        var=tk.StringVar(value=str(value if value is not None else ''));self.vars[key]=var
        ent=tk.Entry(row,textvariable=var,width=width,font=('DejaVu Sans',19),state='readonly' if readonly else 'normal');ent.pack(side='left',fill='x',expand=True)
        ent._numeric=key in ('pack_voltage','pack_ir','capacity_ah')
        if scan:ent._virtual_keyboard=True  # Scanner acts as a keyboard; avoid stealing focus.
        ent.bind('<Return>',self.next_entry)
        if scan and not readonly:a.button(row,'Clavier',lambda:self.app.keyboard.open(ent)).pack(side='right',padx=2)
        var.trace_add('write',self.changed);return ent
    def edit(self,jid):
        if not self.reset():return
        self.current=jid;a=self.app;j=self.store.get(jid);f=j['fields'];pending=self.store.pending(jid)
        a.label(a.body,f"{j['fields'].get('battery_serial') or 'Numéro de batterie à scanner'} — {j['stage']}",True)
        bar=tk.Frame(a.body,bg='#f4f6fa');bar.pack(fill='x')
        a.button(bar,'Liste',self.home).pack(side='left',padx=2)
        a.button(bar,'Enregistrer / Excel',self.save_export).pack(side='left',padx=2)
        if j['stage']!='Terminée' and not pending:
            a.button(bar,'Supprimer du Pi',self.delete_local).pack(side='left',padx=2)
        if pending:a.button(bar,'Réessayer opération ERP',lambda:self.submit(pending)).pack(side='left',padx=2)
        elif j['stage'] in ('Assemblage','Calibrage'):a.button(bar,'Étape terminée',self.advance).pack(side='left',padx=2)
        elif j['stage']=='Mise en boîte':a.button(bar,'Valider la fabrication',self.finalize).pack(side='left',padx=2)
        else:a.button(bar,'Publier correction ERP',self.correction).pack(side='left',padx=2)
        self.status=a.label(a.body,'Brouillon sur le Pi · aucun mouvement avant validation finale' if j['stage']!='Terminée' else 'Fabrication enregistrée dans Dolibarr. Les corrections documentaires ne changent pas le stock.')
        body=a.listing();top=a.card(body)
        self.input(top,'Numéro de batterie','battery_serial',f.get('battery_serial',''),scan=True,readonly=bool(pending))
        self.input(top,'Commentaires','comments',f.get('comments',''),readonly=bool(pending))
        a.label(top,'Modèle : '+j['order']['model'])
        for line in j['order']['lines']:
            if line['role']!='toconsume':continue
            card=a.card(body);a.label(card,f"{line['ref']} · quantité {line['qty']}")
            cl=cell_line(j)
            if cl and line['id']==cl['id'] and int(line['tobatch']):
                a.label(card,'Scannez les numéros directement aux positions C1 à C16 ci-dessous.')
            elif int(line['tobatch']):
                for l,key in serial_keys(j):
                    if l['id']!=line['id']:continue
                    self.input(card,'Série '+key.rsplit('_',1)[-1],key,f.get(key,''),scan=True,readonly=bool(pending))
                    actions=tk.Frame(card,bg='white');actions.pack(fill='x')
                    a.button(actions,'Vérifier en stock',lambda line=line,key=key:self.check_serial(line,key)).pack(side='left',padx=2)
                    if j['stage']!='Terminée' and not pending:a.button(actions,'Défectueux → rebut',lambda line=line,key=key:self.scrap(line,key)).pack(side='left',padx=2)
            else:
                a.label(card,'Consommation automatique de la quantité prévue à la validation finale.')
                if j['stage']!='Terminée' and not pending:a.button(card,'Une unité défectueuse → rebut',lambda line=line:self.scrap(line,None)).pack(anchor='w')
        cells=a.card(body);a.label(cells,'Cellules — C1 côté négatif du pack',True)
        headings=('Position','N° série (facultatif)','Tension (V)','Résistance (mΩ)')
        grid=tk.Frame(cells,bg='white');grid.pack(fill='x')
        for col,label in enumerate(headings):tk.Label(grid,text=label,bg='white',font=('DejaVu Sans',18,'bold')).grid(row=0,column=col,padx=3,pady=6)
        for i in range(1,17):
            tk.Label(grid,text=f'C{i}',bg='white').grid(row=i,column=0)
            for col,name in enumerate(('serial','voltage','ir'),1):
                key=f'cell_{i}_{name}';var=tk.StringVar(value=str(f.get(key,'')));self.vars[key]=var
                ent=tk.Entry(grid,textvariable=var,width=25 if col==1 else 10,state='readonly' if pending else 'normal');ent.grid(row=i,column=col,padx=3,pady=4,sticky='ew');grid.columnconfigure(col,weight=1)
                ent._numeric=col in (2,3)
                if col==1:ent._virtual_keyboard=True
                ent.bind('<Return>',self.next_entry);var.trace_add('write',self.changed)
        cl=cell_line(j)
        if cl and int(cl['tobatch']) and not pending:
            a.label(cells,'Pour remplacer une cellule défectueuse : choisir sa position, puis déclarer le rebut.')
            pos=TouchCombo(cells,values=[str(i) for i in range(1,17)],state='readonly',width=5);pos.set('1');pos.pack(anchor='w')
            a.button(cells,'Cellule défectueuse → rebut',lambda:self.scrap_cell(cl,int(pos.get()))).pack(anchor='w')
        pack=a.card(body)
        self.input(pack,'Tension pack (V)','pack_voltage',f.get('pack_voltage',''),readonly=bool(pending))
        self.input(pack,'Résistance pack (mΩ)','pack_ir',f.get('pack_ir',''),readonly=bool(pending))
        self.input(pack,'Capacité réelle (Ah)','capacity_ah',f.get('capacity_ah',''),readonly=bool(pending))
        if j['stage']!='Assemblage':
            calibration=a.card(body);a.label(calibration,'Résultat du calibrage')
            var=tk.StringVar(value=f.get('calibration_result',''));self.vars['calibration_result']=var
            TouchCombo(calibration,textvariable=var,values=('Conforme','Non conforme'),state='disabled' if pending else 'readonly').pack(fill='x');var.trace_add('write',self.changed)
        if j['stage'] in ('Mise en boîte','Terminée'):
            self.input(pack,'Scellé de garantie','seal',f.get('seal',''),scan=True,readonly=bool(pending))
        if j['stage']!='Terminée' and not pending:a.button(body,'Recharger les composants de l’OF',self.refresh_order).pack(anchor='w',pady=6)
        a.button(body,'Historique local',lambda:self.history(jid)).pack(anchor='w',pady=6)
    def refresh_order(self):
        if not self.save():return
        j=self.store.get(self.current)
        def done(order):
            if order['signature']==j['order']['signature']:
                messagebox.showinfo('OF','La nomenclature de cet OF est inchangée.',parent=self.app.root);return
            if not messagebox.askyesno('OF modifié','Remplacer la liste des composants ? Les numéros des composants devront être revérifiés. Les anciennes saisies restent dans l’historique.',parent=self.app.root):return
            j['order']=order;j['stage']='Assemblage'
            for k in list(j['fields']):
                if k.startswith('serial_'):del j['fields'][k]
            self.store.save(j,self.app.session.user);self.current=None;self.vars={};self.edit(j['id'])
        self.run(lambda:self.request('orders/'+str(j['order']['id'])),done)
    def save_export(self):
        if not self.save():return
        try:
            j=self.store.get(self.current);p=export_local(self.store,j['order']['model']);self.status.config(text='Excel enregistré : '+str(p))
        except Exception as e:messagebox.showerror('Excel',str(e),parent=self.app.root)
    def delete_local(self,jid=None,tests=False):
        if jid is not None:
            self.current=jid
        if not self.current:
            return
        try:j=self.store.get(self.current)
        except ValueError:return
        if self.store.pending(j['id']):
            messagebox.showwarning('Suppression impossible','Une opération ERP est en attente pour cette fiche. Réessayez-la ou résolvez-la avant suppression.',parent=self.app.root);return
        if not messagebox.askyesno('Supprimer du Pi',f"Supprimer la fiche locale de {j['fields'].get('battery_serial') or j['order']['ref']} ?\n\nCela ne modifie pas Dolibarr et ne change aucun stock.",parent=self.app.root):return
        model=j['order']['model']
        self.store.delete_local(j['id'],self.app.session.user or 'local')
        self.current=None;self.vars={}
        try:export_local(self.store,model)
        except Exception as e:messagebox.showwarning('Excel local',str(e),parent=self.app.root)
        self.home(tests=bool(tests))
    def delete_remote(self,mo_id,ref):
        if not messagebox.askyesno('Supprimer dans Dolibarr',f'Supprimer l’OF {ref} non terminé dans Dolibarr ?\n\nLa suppression est refusée si un mouvement de stock existe.',parent=self.app.root):return
        import uuid
        payload={'operation_id':str(uuid.uuid4()),'mo_id':int(mo_id)}
        def done(response):
            # Remove only the matching unfinished local draft, if one exists.
            for job in self.store.all():
                if int(job['order'].get('id',0))==int(mo_id) and job.get('stage')!='Terminée' and not self.store.pending(job['id']):
                    self.store.delete_local(job['id'],self.app.session.user or 'local')
                    try:export_local(self.store,job['order']['model'])
                    except Exception:pass
            messagebox.showinfo('OF supprimé','L’OF non terminé a été supprimé de Dolibarr.',parent=self.app.root)
            self.orders()
        self.run(lambda:self.request('delete',payload),done)
    def advance(self):
        if not self.save():return
        try:
            j=self.store.get(self.current)
            if not messagebox.askyesno('Terminer l’étape',f"Confirmer la fin de l’étape {j['stage']} ?",parent=self.app.root):return
            self.store.transition(j['id'],self.app.session.user);self.current=None;self.vars={};self.edit(j['id']);self.save_export()
        except Exception as e:messagebox.showerror('Étape incomplète',str(e),parent=self.app.root)
    def finalize(self):
        if not self.save():return
        try:
            payload=self.store.final_payload(self.current)
            if not messagebox.askyesno('Valider la fabrication','Consommer les composants, créer UNE batterie en stock et terminer l’OF dans Dolibarr ?',parent=self.app.root):return
            op=self.store.enqueue(self.current,'finalize',payload);self.submit(op)
        except Exception as e:messagebox.showerror('Validation',str(e),parent=self.app.root)
    def correction(self):
        if not self.save():return
        j=self.store.get(self.current)
        if not messagebox.askyesno('Correction documentaire','Ajouter cette version aux notes de l’OF ? Les numéros des mouvements de stock restent inchangés.',parent=self.app.root):return
        self.submit(self.store.enqueue(j['id'],'correction',{'document_id':j['id'],'mo_id':j['order']['id'],'fields':j['fields']}))
    def check_serial(self,line,key):
        from urllib.parse import urlencode
        value=self.vars[key].get().strip()
        self.run(lambda:self.request('serial?'+urlencode({'product_id':line['product_id'],'serial':value})),lambda r:messagebox.showinfo('Stock','Numéro disponible en stock.',parent=self.app.root))
    def scrap_cell(self,line,position):
        if not self.save():return
        # Reuse the regular stock operation, but clear the position field too.
        self.scrap(line,f'cell_{position}_serial')
    def scrap(self,line,key):
        if not self.save():return
        a=self.app;j=self.store.get(self.current);w=a.dialog('Déclarer une unité défectueuse')
        a.label(w,line['ref']+' · '+(j['fields'].get(key,'') if key else '1 unité'))
        a.label(w,'Motif obligatoire');reason=tk.Entry(w);reason.pack(fill='x')
        a.label(w,'Une unité sera retirée du stock immédiatement. Elle ne sera pas consommée lors de la validation finale.')
        def go():
            if not messagebox.askyesno('Rebut','Confirmer la sortie définitive d’une unité ?',parent=w):return
            op=self.store.enqueue(j['id'],'scrap',{'mo_id':j['order']['id'],'line_id':line['id'],'serial':j['fields'].get(key,'') if key else '', 'field_key':key,'reason':reason.get()});a.keyboard.close();w.destroy();self.submit(op)
        a.button(w,'Sortir du stock',go).pack(pady=10)
    def history(self,jid):
        w=self.app.dialog('Historique');text=tk.Text(w,height=12,wrap='word');text.pack(fill='both',expand=True)
        for r in self.store.history(jid):
            old=json.loads(r['before_json']) or {};new=json.loads(r['after_json']);changes=[k for k,v in new.get('fields',{}).items() if old.get('fields',{}).get(k)!=v]
            text.insert('end',f"{r['at']} · {r['actor']} · {', '.join(changes) or new['stage']}\n")
        text.config(state='disabled')
    def exports(self):
        if not self.reset():return
        a=self.app;a.label(a.body,'Excel local et NAS',True);a.button(a.body,'Retour',self.home).pack(anchor='w')
        a.label(a.body,'Fermez le classeur sur les autres postes avant synchronisation. Les anciennes fiches non gérées par la borne sont conservées.')
        models=sorted({j['order']['model'] for j in self.store.all()})
        frame=a.listing()
        for model in models:
            card=a.card(frame);a.label(card,model)
            a.button(card,'Exporter sur le Pi',lambda m=model:self.export_one(m)).pack(side='left',padx=3)
            a.button(card,'Synchroniser NAS',lambda m=model:self.sync(m)).pack(side='left',padx=3)
        a.label(a.body,'Dossier local : '+str(data_dir()/'excel'))
    def export_one(self,model):
        try:messagebox.showinfo('Excel',str(export_local(self.store,model)),parent=self.app.root)
        except Exception as e:messagebox.showerror('Excel',str(e),parent=self.app.root)
    def sync(self,model,resolutions=None):
        try:
            path=config_path().with_name('fabrication.json')
            conf=json.loads(path.read_text()) if path.exists() else {}
            if not conf.get('nas_directory'):raise ValueError('Configurez le dossier NAS avec configurer_fabrication.py lorsque son chemin sera connu.')
            out=sync_nas(self.store,model,conf['nas_directory'],resolutions)
            messagebox.showinfo('NAS','Synchronisé : '+str(out)+'\nLes corrections des batteries terminées peuvent être publiées depuis leur fiche.',parent=self.app.root)
        except MergeConflict as e:self.conflicts(model,e)
        except Exception as e:messagebox.showerror('NAS',str(e),parent=self.app.root)
    def conflicts(self,model,error):
        a=self.app
        if not self.reset():return
        a.label(a.body,'Conflits Excel — choisissez chaque valeur',True)
        decisions={'fingerprint':error.fingerprint};frame=a.listing()
        for c in error.conflicts:
            card=a.card(frame);j=self.store.get(c['job']);a.label(card,j['fields'].get('battery_serial','')+' · '+c['field'])
            var=tk.StringVar(value='')
            for key,title in [('pi','Pi'),('nas','NAS')]:
                tk.Radiobutton(card,text=title+' : '+str(c[key]),variable=var,value=key,bg='white',command=lambda c=c,v=var:decisions.update({c['job']+'|'+c['field']:v.get()})).pack(anchor='w')
        a.button(a.body,'Appliquer les choix',lambda:self.sync(model,decisions)).pack(side='bottom')
