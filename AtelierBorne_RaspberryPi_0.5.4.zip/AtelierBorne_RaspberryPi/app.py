#!/usr/bin/env python3
"""AtelierBorne — prototype Linux natif, démonstration ou lecture Dolibarr."""
import argparse
import html
import queue
import threading
from dolibarr_client import load_client, load_personal_client, stock_quantity, ApiError
from manufacturing_ui import ManufacturingUI
from touch_keyboard import TouchKeyboard, grab_when_visible
import datetime as dt
import os
from pathlib import Path
import sqlite3
import tkinter as tk
from tkinter import ttk

BLUE = '#215bc5'
BG = '#f4f6fa'
try:
    from comptes_locaux import COMPTES
except ModuleNotFoundError as exc:
    if exc.name != 'comptes_locaux': raise
    from comptes_exemple import COMPTES
PEOPLE = tuple(COMPTES)

class Session:
    def __init__(self): self.user = None
    def login(self, name, password):
        self.user = None
        if name not in COMPTES or COMPTES[name] != password:
            return False
        self.user = name
        return True
    def logout(self): self.user = None


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,title TEXT,project TEXT,owner TEXT,progress INTEGER);
        CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT,serial INTEGER);
        CREATE TABLE IF NOT EXISTS stock(product TEXT,warehouse TEXT,qty INTEGER CHECK(qty>=0),PRIMARY KEY(product,warehouse));
        CREATE TABLE IF NOT EXISTS serials(code TEXT PRIMARY KEY,product TEXT,warehouse TEXT,active INTEGER);
        CREATE TABLE IF NOT EXISTS leaves(id INTEGER PRIMARY KEY,person TEXT,start TEXT,end TEXT,status TEXT);
        CREATE TABLE IF NOT EXISTS journal(id INTEGER PRIMARY KEY,at TEXT,person TEXT,action TEXT);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
        ''')
        if not self.db.execute("SELECT 1 FROM meta WHERE key='seed'").fetchone():
            with self.db:
                self.db.executemany('INSERT INTO tasks VALUES(?,?,?,?,?)', [(1,'Préparer les kits du lot suivant','Assemblage',None,0),(2,'Compléter les fiches de contrôle','Qualité',None,0),(3,'Vérifier la réception des boîtiers','Stock','Hery',40)])
                self.db.executemany('INSERT INTO products VALUES(?,?,?)', [('CELL-314','Cellules LFP 314 Ah',0),('BMS-16S','BMS 16S',1),('BAT-LV','Batterie LV assemblée',1),('BOX-LV','Boîtiers LV',0)])
                for product, a, m in [('CELL-314',64,128),('BMS-16S',2,0),('BAT-LV',1,0),('BOX-LV',12,0)]:
                    self.db.executemany('INSERT INTO stock VALUES(?,?,?)',[(product,'Atelier',a),(product,'Magasin',m)])
                self.db.executemany('INSERT INTO serials VALUES(?,?,?,1)', [('BMS-00041','BMS-16S','Atelier'),('BMS-00042','BMS-16S','Atelier'),('BAT-00108','BAT-LV','Atelier')])
                today = dt.date.today()
                for person, offset in [('Miora',7),('Lova',15)]:
                    self.db.execute('INSERT INTO leaves(person,start,end,status) VALUES(?,?,?,?)',(person,str(today+dt.timedelta(days=offset)),str(today+dt.timedelta(days=offset+2)),'Validée (démo)'))
                self.db.execute("INSERT INTO meta VALUES('seed','1')")
    def rows(self, sql, args=()):
        return self.db.execute(sql,args).fetchall()
    def log(self, person, action):
        self.db.execute('INSERT INTO journal(at,person,action) VALUES(?,?,?)',(dt.datetime.now().isoformat(timespec='seconds'),person,action))
    def task(self, ident, action, person):
        if person not in PEOPLE or action not in ('Prendre','Démarrer','Terminer'): raise ValueError('Action ou opérateur inconnu.')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.rows('SELECT * FROM tasks WHERE id=?',(ident,))[0]
            if action == 'Prendre':
                if row['owner']: raise ValueError('Cette tâche est déjà prise.')
                self.db.execute('UPDATE tasks SET owner=? WHERE id=?',(person,ident))
            else:
                if row['owner'] != person: raise ValueError('Seule la personne qui a pris la tâche peut la modifier.')
                if row['progress'] == 100: raise ValueError('Cette tâche est déjà terminée.')
                progress = 1 if action == 'Démarrer' else 100
                self.db.execute('UPDATE tasks SET progress=? WHERE id=?',(progress,ident))
            self.log(person,f'Tâche {ident} : {action}')
    def movement(self, product, warehouse, mode, quantity, serial, reason, person, expected):
        if not reason.strip(): raise ValueError('Indiquez un motif.')
        try: quantity = int(quantity)
        except (ValueError, TypeError): raise ValueError('La quantité doit être un nombre entier.')
        if quantity < 0 or (mode != 'Inventaire' and quantity == 0): raise ValueError('Quantité incorrecte.')
        serial = serial.strip().upper()
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            p = self.rows('SELECT * FROM products WHERE id=?',(product,))
            stocks = self.rows('SELECT qty FROM stock WHERE product=? AND warehouse=?',(product,warehouse))
            if not p or not stocks: raise ValueError('Produit ou entrepôt inconnu.')
            old = stocks[0]['qty']
            if mode not in ('Entrée','Sortie','Inventaire'): raise ValueError('Mouvement inconnu.')
            if p[0]['serial']:
                if mode == 'Inventaire': raise ValueError('Pour un produit sérialisé, utilisez une entrée ou une sortie par numéro.')
                if quantity != 1 or not serial: raise ValueError('Un numéro de série et une quantité de 1 sont obligatoires.')
                if len(serial)>100: raise ValueError('Numéro trop long (100 caractères maximum).')
                existing = self.rows('SELECT * FROM serials WHERE code=?',(serial,))
                if mode == 'Entrée':
                    if existing: raise ValueError('Ce numéro existe déjà dans le registre, même après une sortie.')
                    self.db.execute('INSERT INTO serials VALUES(?,?,?,1)',(serial,product,warehouse))
                else:
                    if not existing or not existing[0]['active'] or existing[0]['product'] != product or existing[0]['warehouse'] != warehouse:
                        raise ValueError('Ce numéro ne se trouve pas dans ce stock.')
                    self.db.execute('UPDATE serials SET active=0 WHERE code=?',(serial,))
            if mode == 'Inventaire' and old != expected: raise ValueError('Le stock a changé. Fermez puis rouvrez ce formulaire.')
            new = quantity if mode == 'Inventaire' else old + (quantity if mode == 'Entrée' else -quantity)
            if new < 0: raise ValueError('Stock insuffisant.')
            self.db.execute('UPDATE stock SET qty=? WHERE product=? AND warehouse=?',(new,product,warehouse))
            self.log(person,f'{mode} {product} / {warehouse} : {old} → {new}; série {serial or "—"}; {reason.strip()}')
    def leave(self, person, start, end):
        try: a,b = dt.date.fromisoformat(start),dt.date.fromisoformat(end)
        except ValueError: raise ValueError('Dates invalides. Format : AAAA-MM-JJ.')
        if b<a: raise ValueError('La fin doit être après le début.')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            if self.rows('SELECT 1 FROM leaves WHERE person=? AND start<=? AND end>=?',(person,end,start)):
                raise ValueError('Ces dates recouvrent une demande existante.')
            self.db.execute('INSERT INTO leaves(person,start,end,status) VALUES(?,?,?,?)',(person,start,end,'En attente (démo)'))
            self.log(person,f'Demande de vacances : {start} au {end}')

class App:
    def __init__(self, root, store, fullscreen=True, client=None):
        self.root, self.store = root, store
        self.client = client
        self.default_client = client
        self.personal = False
        self.api_identity = None
        self.keyboard = TouchKeyboard(root)
        self.view_generation = 0
        self.session = Session()
        self.flash = ""
        self.tab = 1
        self.filter = 'À prendre'
        self.warehouse = 'Atelier'
        root.title('AtelierBorne — Dolibarr' if client else 'AtelierBorne — démonstration')
        root.geometry('1024x700')
        root.configure(bg=BG)
        root.option_add('*Font', 'Sans 13')
        root.attributes('-fullscreen', fullscreen)
        root.bind('<Escape>', lambda e: root.attributes('-fullscreen',False))
        root.bind('<F11>', lambda e: root.attributes('-fullscreen',not root.attributes('-fullscreen')))
        root.bind('<Control-Shift-Q>',lambda e:self.shutdown())
        root.bind('<Control-Shift-q>',lambda e:self.shutdown())
        root.protocol('WM_DELETE_WINDOW',self.shutdown)
        header = tk.Frame(root,bg='white',padx=6,pady=6); header.pack(fill='x')
        self.header=header
        tk.Label(header,text='ATELIER',font=('Sans',16,'bold'),bg='white').pack(side='left',padx=(2,8))
        self.logout_button = tk.Button(header,text='Déconnexion',command=self.logout,font=('Sans',11),padx=8,pady=14,relief='flat')
        nav = tk.Frame(header,bg='white'); self.nav = nav
        self.tabs=[]
        for i,title in enumerate(('Vacances','Projets / Tâches','Stocks','Tests / Réglages','Fabrication')):
            b=tk.Button(nav,text=title,command=lambda i=i:self.show(i),height=0,pady=14,padx=4,font=('Sans',11),relief='flat')
            b.grid(row=0,column=i,sticky='nsew',padx=2)
            nav.columnconfigure(i,weight=1,uniform='tabs')
            self.tabs.append(b)
        self.identity = tk.Label(root,text='',bg=BG,fg='#5a6577',font=('Sans',10),anchor='w')
        self.identity.pack(fill='x',padx=12,pady=2)
        self.body=tk.Frame(root,bg=BG,padx=18,pady=8); self.body.pack(fill='both',expand=True)
        tk.Label(root,text='Essai VNC : Échap = mode fenêtre · F11 = plein écran · Ctrl+Maj+Q = quitter',bg=BG,fg='#5a6577',font=('Sans',10)).pack(pady=5)
        self.manufacturing=ManufacturingUI(self)
        self.login_screen()
    def shutdown(self):
        if hasattr(self,"manufacturing"):self.manufacturing.flush()
        self.view_generation+=1
        self.keyboard.shutdown()
        self.root.destroy()
    def login_screen(self):
        self.keyboard.close()
        self.nav.pack_forget()
        self.logout_button.pack_forget()
        self.identity.config(text="")
        for w in self.body.winfo_children(): w.destroy()
        self.label(self.body,"Connexion à l’atelier",True)
        self.label(self.body,"Identifiez-vous pour accéder aux onglets.")
        person=ttk.Combobox(self.body,values=PEOPLE,state="readonly")
        person.set(PEOPLE[0] if PEOPLE else ""); person.pack(anchor="w",pady=12)
        pin=tk.Entry(self.body,show="•"); pin.pack(anchor="w",pady=12); pin.focus_set()
        status=self.label(self.body,"")
        def connect():
            if not self.session.login(person.get(),pin.get()):
                pin.delete(0,"end"); status.config(text="Identifiant ou mot de passe incorrect."); return
            try:
                personal=load_personal_client(self.session.user) if self.default_client else None
            except ApiError as e:
                self.session.logout();status.config(text=str(e));return
            self.personal=personal is not None
            self.client=personal or self.default_client
            self.api_identity=None
            self.identity.config(text=self.session.user+(' · Dolibarr personnel' if self.personal else ' · Dolibarr — compte partagé, lecture seule' if self.client else ' · DÉMO locale'))
            self.keyboard.close()
            self.logout_button.pack(side='right',padx=(6,0))
            self.nav.pack(side='left',fill='x',expand=True)
            self.show(1)
        self.button(self.body,"Se connecter",connect).pack(anchor="w",pady=12)
        pin.bind("<Return>",lambda e:connect())
    def logout(self):
        if hasattr(self,"manufacturing"):
            self.manufacturing.flush();self.manufacturing.current=None;self.manufacturing.vars={}
        self.view_generation += 1
        self.keyboard.close()
        self.session.logout()
        self.client=self.default_client;self.personal=False;self.api_identity=None
        for w in self.root.winfo_children():
            if isinstance(w,tk.Toplevel): w.destroy()
        self.filter="À prendre"; self.warehouse="Atelier"; self.flash=""
        self.login_screen()
    def button(self,parent,text,command):
        def invoke():
            # A visible touch keyboard owns the modal grab. Release it before
            # any action button so dialog confirmations remain tappable.
            self.keyboard.close()
            return command()
        b=tk.Button(parent,text=text,command=invoke,bg=BLUE,fg='white',activebackground='#174393',activeforeground='white',relief='flat',padx=16,pady=10)
        return b
    def label(self,parent,text,large=False):
        w=tk.Label(parent,text=text,bg=parent.cget('bg'),anchor='w',justify='left',wraplength=760,font=('Sans',18,'bold') if large else ('Sans',13))
        w.pack(fill='x',pady=6); return w
    def listing(self):
        frame=tk.Frame(self.body,bg=BG); frame.pack(fill='both',expand=True,pady=8)
        canvas=tk.Canvas(frame,bg=BG,highlightthickness=0)
        bar=tk.Scrollbar(frame,orient='vertical',command=canvas.yview,width=28)
        bar.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=bar.set)
        content=tk.Frame(canvas,bg=BG); item=canvas.create_window((0,0),window=content,anchor='nw')
        content.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        return content
    def card(self,parent):
        f=tk.Frame(parent,bg='white',padx=14,pady=10);f.pack(fill='x',pady=5);return f
    def dialog(self,title):
        w=tk.Toplevel(self.root); w.title(title); w.transient(self.root); w.configure(bg='white',padx=20,pady=15)
        w.geometry(f'620x470+{max(0,self.root.winfo_rootx()+30)}+{max(0,self.root.winfo_rooty()+30)}')
        grab_when_visible(w); w.bind('<Escape>',lambda e:w.destroy())
        self.label(w,title,True)
        self.button(w,'Fermer',w.destroy).pack(side='bottom',anchor='e',pady=5)
        return w
    def notify(self,title,text):
        w=self.dialog(title);self.label(w,text);return w
    def authenticated(self,callback):
        if self.session.user is None:
            self.login_screen()
            return
        callback(self.session.user)
    def perform(self,call,dialog=None):
        try:call()
        except (ValueError,sqlite3.Error) as e:self.notify('Action impossible',str(e));return False
        if dialog:self.keyboard.close();dialog.destroy()
        self.show(self.tab);return True
    def show(self,index):
        if hasattr(self,"manufacturing") and self.manufacturing.current:
            if not self.manufacturing.save():return
            self.manufacturing.current=None;self.manufacturing.vars={}
        self.keyboard.close()
        if self.session.user is None:
            self.login_screen(); return
        self.view_generation += 1
        self.tab=index
        for i,b in enumerate(self.tabs):b.config(bg=BLUE if i==index else 'white',fg='white' if i==index else '#172338')
        for w in self.body.winfo_children():w.destroy()
        if index == 4 or (index == 3 and self.client):
            self.manufacturing.home(tests=index==3);return
        if self.client:
            if index == 1:self.remote_projects()
            elif index == 2:self.remote_stocks()
            elif index == 0:
                self.label(self.body,'Vacances' if index == 0 else 'Stocks',True)
                self.label(self.body,'Connexion de cette rubrique en préparation. Aucune donnée fictive n’est affichée en mode Dolibarr.')
                if index == 0:self.label(self.body,'Vos soldes existants seront lus depuis Dolibarr après raccordement du service de congés et des utilisateurs.')
            else:self.technical()
        else:(self.vacances,self.tasks,self.stocks,self.technical)[index]()
    def remote_fetch(self, action, render):
        generation=self.view_generation
        user=self.session.user
        status=self.label(self.body,'Chargement depuis Dolibarr…')
        results=queue.Queue()
        def worker():
            try:results.put((True,action()))
            except ApiError as e:results.put((False,str(e)))
            except Exception:results.put((False,'Erreur inattendue lors de la lecture. Aucune donnée locale de démonstration ne sera substituée.'))
        def poll():
            if self.view_generation != generation or self.session.user != user:return
            try:ok,result=results.get_nowait()
            except queue.Empty:self.root.after(100,poll);return
            if ok:
                status.config(text='Lecture réussie à '+dt.datetime.now().strftime('%H:%M:%S'))
                render(result)
            else:status.config(text=result,fg='#a02020')
        threading.Thread(target=worker,daemon=True).start()
        self.root.after(100,poll)
    def remote_projects(self):
        self.label(self.body,'Projets Dolibarr',True)
        self.label(self.body,'Projets partagés et projets dont vous êtes membre' if self.personal else 'Projets partagés · lecture seule')
        self.button(self.body,'Actualiser les projets',lambda:self.show(1)).pack(anchor='w')
        if self.personal:self.button(self.body,'Tâches non assignées — À prendre',self.remote_available).pack(anchor='w',pady=4)
        else:self.label(self.body,'Associez votre compte Dolibarr pour afficher vos projets privés et prendre une tâche. Seuls les projets partagés sont affichés ici.')
        def render(rows):
            area=self.listing()
            if not rows:self.label(area,'Aucun projet renvoyé par ce compte. Vérifiez ses droits et les restrictions aux tiers/commerciaux si des projets existent.')
            for r in rows:
                f=self.card(area)
                title=html.unescape(str(r.get('title') or r.get('label') or r.get('ref') or r['id']))
                self.label(f,title,True)
                self.label(f,str(r.get('ref') or '')+' · '+('Partagé' if str(r.get('public'))=='1' else 'Personnel'))
                self.button(f,'Voir les tâches',lambda r=r,title=title:self.remote_tasks(r['id'],title)).pack(anchor='e')
        client=self.client
        self.remote_fetch(client.personal_projects if self.personal else lambda:[r for r in client.projects() if str(r.get('public'))=='1'],render)
    def remote_tasks(self,ident,title):
        if not self.session.user:self.login_screen();return
        self.view_generation+=1
        for w in self.body.winfo_children():w.destroy()
        self.label(self.body,title,True)
        actions=tk.Frame(self.body,bg=BG);actions.pack(fill='x')
        self.button(actions,'Retour aux projets',lambda:self.show(1)).pack(side='left',padx=3)
        self.button(actions,'Actualiser',lambda:self.remote_tasks(ident,title)).pack(side='left',padx=3)
        def render(rows):
            area=self.listing()
            if not rows:self.label(area,'Aucune tâche renvoyée pour ce projet.')
            for r in rows:
                f=self.card(area)
                self.label(f,html.unescape(str(r.get('label') or r.get('title') or r.get('ref') or 'Tâche')),True)
                progress=r.get('progress')
                try:
                    value=float(progress)
                    detail=f'{value:g} %' if 0<=value<=100 else 'non renseignée'
                except (ValueError,TypeError):detail='non renseignée'
                self.label(f,str(r.get('ref') or '')+' · Progression : '+detail)
                if self.personal:self.task_assignment(f,r,lambda:self.remote_tasks(ident,title))
            self.label(area,'Touchez Prendre pour vous affecter une tâche disponible.' if self.personal else 'Prise de tâche disponible après association personnelle et installation du module.')
        client=self.client
        self.remote_fetch(lambda:client.personal_tasks(ident) if self.personal else client.tasks(ident),render)
    def remote_stocks(self):
        self.label(self.body,'Stocks Dolibarr',True)
        self.label(self.body,'Stock physique total, tous entrepôts · consultation')
        self.button(self.body,'Actualiser',lambda:self.show(2)).pack(anchor='w')
        search=tk.Entry(self.body);search.pack(fill='x',pady=6)
        self.label(self.body,'Rechercher par référence ou nom')
        client=self.client
        def render(rows):
            area=self.listing()
            def refresh(*args):
                for child in area.winfo_children():child.destroy()
                term=search.get().casefold();count=0
                for r in rows:
                    name=html.unescape(str(r.get('label') or ''));ref=str(r.get('ref') or '')
                    if term not in (ref+' '+name).casefold():continue
                    count+=1;f=self.card(area);self.label(f,ref+' · '+name,True)
                    quantity=stock_quantity(r)
                    self.label(f,'Quantité : '+(format(quantity,'f') if quantity is not None else 'indisponible — vérifier le droit de lecture des stocks'))
                if not count:self.label(area,'Aucun produit correspondant.')
            value=tk.StringVar(value=search.get());search.config(textvariable=value)
            search._filter_var=value;value.trace_add('write',refresh);refresh()
        self.remote_fetch(client.products,render)
    def remote_available(self):
        self.keyboard.close();self.view_generation+=1
        for w in self.body.winfo_children():w.destroy()
        self.label(self.body,'Tâches non assignées',True)
        self.button(self.body,'Retour aux projets',lambda:self.show(1)).pack(anchor='w')
        self.button(self.body,'Actualiser',self.remote_available).pack(anchor='w',pady=4)
        client=self.client
        def render(rows):
            area=self.listing()
            if not rows:self.label(area,'Aucune tâche disponible dans vos projets accessibles.')
            for r in rows:
                f=self.card(area);self.label(f,html.unescape(str(r.get('label') or r.get('ref'))),True)
                self.label(f,html.unescape(str(r.get('project_title') or '')))
                self.task_assignment(f,r,self.remote_available)
        self.remote_fetch(client.available_tasks,render)
    def task_assignment(self,parent,row,refresh):
        if row.get('mine'):self.label(parent,'Prise par vous');return
        if int(row.get('assigned_count',0))>0:self.label(parent,'Déjà attribuée');return
        try:available=float(row.get('progress') or 0)<100 and int(row.get('project_status',0))==1
        except (ValueError,TypeError):available=False
        if not available:self.label(parent,'Non disponible à la prise');return
        self.button(parent,'Prendre',lambda:self.confirm_claim(row,refresh)).pack(anchor='e')
    def confirm_claim(self,row,refresh):
        client=self.client;actor=self.session.user
        w=self.dialog('Prendre cette tâche')
        self.label(w,html.unescape(str(row.get('label') or row.get('ref') or 'Tâche')))
        self.label(w,'La tâche sera affectée à votre compte Dolibarr personnel.')
        status=self.label(w,'')
        def send():
            if self.session.user != actor:w.destroy();return
            button.config(state='disabled');status.config(text='Affectation en cours…')
            result=queue.Queue()
            def worker():
                try:result.put((True,client.claim(row['id'])))
                except ApiError as e:result.put((False,str(e)))
                except Exception:result.put((False,'Résultat incertain. Actualisez la liste avant de réessayer.'))
            def poll():
                if not w.winfo_exists():return
                try:ok,data=result.get_nowait()
                except queue.Empty:self.root.after(100,poll);return
                if ok:w.destroy();refresh()
                else:status.config(text=str(data));button.config(state='normal')
            threading.Thread(target=worker,daemon=True).start();self.root.after(100,poll)
        button=self.button(w,'Confirmer la prise',send);button.pack(pady=10)
    def tasks(self):
        self.label(self.body,'Projets / Tâches',True)
        line=tk.Frame(self.body,bg=BG);line.pack(fill='x')
        for value in ('À prendre','Prises en charge','Terminées'):
            def select(v=value):self.filter=v;self.show(1)
            self.button(line,('✓ ' if self.filter==value else '')+value,select).pack(side='left',padx=3)
        area=self.listing();count=0
        for r in self.store.rows('SELECT * FROM tasks ORDER BY id'):
            category='Terminées' if r['progress']==100 else 'Prises en charge' if r['owner'] else 'À prendre'
            if category!=self.filter:continue
            count+=1;f=self.card(area);self.label(f,r['title'],True)
            self.label(f,f"{r['project']} · {r['owner'] or 'Non attribuée'} · {r['progress']} %")
            if r['progress']<100:
                action='Prendre' if not r['owner'] else 'Démarrer' if r['progress']==0 else 'Terminer'
                self.button(f,action,lambda r=r,a=action:self.authenticated(lambda p:self.perform(lambda:self.store.task(r['id'],a,p)))).pack(anchor='e')
        if not count:self.label(area,'Aucune tâche dans cette liste.')
    def vacances(self):
        self.label(self.body,'Vacances',True)
        if self.flash:
            self.label(self.body,self.flash).config(fg='#16703a')
            self.flash=''
        self.button(self.body,'Demander des vacances',lambda:self.authenticated(self.leave_form)).pack(anchor='w')
        area=self.listing()
        self.label(area,'Mes demandes · '+self.session.user,True)
        mine=self.store.rows('SELECT * FROM leaves WHERE person=? ORDER BY start DESC,id DESC',(self.session.user,))
        if not mine: self.label(area,'Aucune demande pour le moment.')
        for r in mine:
            f=self.card(area)
            self.label(f,f"Du {r['start']} au {r['end']} · {r['status']}")
        self.label(area,'Planning des absences validées',True)
        for r in self.store.rows("SELECT * FROM leaves WHERE status='Validée (démo)' ORDER BY start"):
            f=self.card(area);self.label(f,r['person'],True);self.label(f,f"Du {r['start']} au {r['end']} · {r['status']}")
    def leave_form(self,person):
        w=self.dialog(f'Vacances · {person}')
        self.label(w,'Nouvelle demande — dates au format AAAA-MM-JJ')
        entries=[]
        for name in ('Début','Fin'):
            self.label(w,name);e=tk.Entry(w);e.insert(0,str(dt.date.today()));e.pack(fill='x');entries.append(e)
        status=self.label(w,'')
        def submit():
            if self.session.user != person:
                w.destroy();self.login_screen();return
            try:self.store.leave(person,entries[0].get(),entries[1].get())
            except (ValueError,sqlite3.Error) as e:
                status.config(text=str(e),fg='#a02020');return
            self.flash='Demande enregistrée · en attente de validation (démo).'
            self.keyboard.close();w.destroy();self.show(0)
        self.button(w,'Enregistrer la demande (démo)',submit).pack(pady=12)
    def stocks(self):
        line=tk.Frame(self.body,bg=BG);line.pack(fill='x')
        self.label(line,'Stocks',True)
        warehouses=ttk.Combobox(line,values=('Atelier','Magasin'),state='readonly');warehouses.set(self.warehouse);warehouses.pack(anchor='w')
        def changed(e):self.warehouse=warehouses.get();self.show(2)
        warehouses.bind('<<ComboboxSelected>>',changed)
        area=self.listing()
        for r in self.store.rows('SELECT p.*,s.qty FROM products p JOIN stock s ON s.product=p.id WHERE s.warehouse=? ORDER BY p.id',(self.warehouse,)):
            f=self.card(area);self.label(f,f"{r['name']} : {r['qty']}",True)
            self.label(f,r['id']+(' · numéros de série uniques' if r['serial'] else ' · suivi en quantité'))
            buttons=tk.Frame(f,bg='white');buttons.pack(fill='x')
            self.button(buttons,'Modifier',lambda r=r:self.authenticated(lambda p:self.stock_form(r,p))).pack(side='right')
            if r['serial']:
                self.button(buttons,'Numéros de série',lambda r=r:self.serial_list(r)).pack(side='left')
    def serial_list(self,r):
        rows=self.store.rows('SELECT code FROM serials WHERE product=? AND warehouse=? AND active=1 ORDER BY code',(r['id'],self.warehouse))
        w=self.dialog('Numéros présents · '+r['id']);box=tk.Text(w,height=10,font=('Sans',15));box.pack(fill='both',expand=True)
        box.insert('1.0','\n'.join(x['code'] for x in rows) or 'Aucun numéro présent.');box.config(state='disabled')
    def stock_form(self,r,person):
        warehouse=self.warehouse
        w=self.dialog(f"{r['id']} · {warehouse} · {person}");w.geometry('620x590')
        self.label(w,f"Stock affiché : {r['qty']} · modification locale de démonstration")
        mode=ttk.Combobox(w,values=('Entrée','Sortie') if r['serial'] else ('Entrée','Sortie','Inventaire'),state='readonly');mode.set('Entrée');mode.pack(fill='x',pady=8)
        self.label(w,'Quantité (Inventaire = quantité totale comptée)')
        qty=tk.Entry(w);qty.insert(0,'1');qty.pack(fill='x')
        if r['serial']:qty.config(state='readonly')
        self.label(w,'Numéro de série' if r['serial'] else 'Numéro de série : non requis')
        serial=tk.Entry(w);serial.pack(fill='x')
        if not r['serial']:serial.config(state='disabled')
        self.label(w,'Motif obligatoire');reason=tk.Entry(w);reason.pack(fill='x')
        self.button(w,'Enregistrer (démo)',lambda:self.perform(lambda:self.store.movement(r['id'],warehouse,mode.get(),qty.get(),serial.get(),reason.get(),person,r['qty']),w)).pack(pady=15)
    def technical(self):
        self.label(self.body,'Tests + Pré-configuration calibrage',True)
        self.label(self.body,'Emplacements prévus pour la future intégration des équipements.')
        area=self.listing()
        for title,description in [('Tests','Sélectionner à terme un appareil et une procédure validée.'),('Pré-configuration','Préparer à terme les paramètres autorisés pour un modèle.'),('Calibrage','À définir selon le matériel et la procédure du fabricant.')]:
            f=self.card(area);self.label(f,title,True);self.label(f,description)
            self.button(f,'État de l’intégration',lambda title=title:self.notify(title,'Non connecté.\nAucune mesure, aucun test ni réglage matériel ne sont exécutés dans ce prototype.')).pack(anchor='e')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--windowed',action='store_true');parser.add_argument('--demo',action='store_true');args=parser.parse_args()
    try:client=None if args.demo else load_client()
    except ApiError as e:raise SystemExit(str(e))
    directory=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'atelierborne'
    directory.mkdir(parents=True,exist_ok=True)
    store=Store(directory/'demo.sqlite3')
    try:root=tk.Tk()
    except tk.TclError as e:
        raise SystemExit('Impossible d’ouvrir la session graphique. Lancez ce programme depuis un terminal OUVERT DANS VNC.\n'+str(e))
    App(root,store,not args.windowed,client)
    try:root.mainloop()
    finally:store.db.close()
if __name__=='__main__':main()
