"""Clavier tactile natif, sans dépendance externe."""
import tkinter as tk
from tkinter import ttk

class TouchKeyboard:
    def __init__(self, root):
        self.root=root;self.window=None;self.target=None;self.previous_grab=None
        root.bind_all('<FocusIn>',self.request,add='+')
        root.bind_all('<ButtonRelease-1>',self.request,add='+')
    def request(self,event):
        widget=event.widget
        if not isinstance(widget,(tk.Entry,ttk.Entry)) or getattr(widget,'_virtual_keyboard',False):return
        try:
            if str(widget.cget('state')) not in ('normal',''):return
        except tk.TclError:return
        self.root.after_idle(lambda:self.open(widget))
    def open(self,target):
        if not target.winfo_exists() or str(target.cget('state')) not in ('normal',''):return
        if self.window is not None:
            if self.target==target:return
            self.close()
        self.target=target;self.upper=False;self.symbols=False
        self.previous_grab=self.root.grab_current()
        w=tk.Toplevel(self.root);self.window=w
        w.title('Clavier tactile');w.transient(target.winfo_toplevel());w.overrideredirect(True)
        w.configure(bg='#dbe2ef',padx=8,pady=8)
        width=min(1000,self.root.winfo_screenwidth())
        height=min(330,self.root.winfo_screenheight()-20)
        x=max(0,self.root.winfo_rootx()+(self.root.winfo_width()-width)//2)
        y=max(0,self.root.winfo_rooty()+self.root.winfo_height()-height)
        w.geometry(f'{width}x{height}+{x}+{y}')
        self.value=tk.StringVar(value=target.get())
        self.preview=tk.Entry(w,textvariable=self.value,show=target.cget('show'),font=('Sans',17))
        self.preview._virtual_keyboard=True;self.preview.pack(fill='x',pady=(0,6))
        self.preview.icursor('end');self.preview.focus_set()
        self.keys=tk.Frame(w,bg='#dbe2ef');self.keys.pack(fill='both',expand=True)
        controls=tk.Frame(w,bg='#dbe2ef');controls.pack(fill='x',pady=(6,0))
        for label,action in [('Maj',self.shift),('Symboles',self.toggle),('Espace',lambda:self.insert(' ')),('Effacer',self.backspace),('Terminé',self.close)]:
            tk.Button(controls,text=label,command=action,takefocus=0,font=('Sans',13),pady=8).pack(side='left',expand=True,fill='x',padx=2)
        self.value.trace_add('write',self.sync)
        w.bind('<Escape>',lambda e:self.close());w.bind('<Return>',lambda e:self.close())
        self.render();w.grab_set()
    def sync(self,*args):
        try:
            if self.target and self.target.winfo_exists():
                self.target.delete(0,'end');self.target.insert(0,self.value.get())
        except tk.TclError:self.close()
    def insert(self,text):
        try:self.preview.delete('sel.first','sel.last')
        except tk.TclError:pass
        self.preview.insert('insert',text);self.preview.focus_set()
    def backspace(self):
        try:self.preview.delete('sel.first','sel.last')
        except tk.TclError:
            pos=self.preview.index('insert')
            if pos:self.preview.delete(pos-1,pos)
    def shift(self):self.upper=not self.upper;self.render()
    def toggle(self):self.symbols=not self.symbols;self.render()
    def render(self):
        for child in self.keys.winfo_children():child.destroy()
        rows=['1234567890','azertyuiop','qsdfghjklm','wxcvbnéèàç'] if not self.symbols else ['!@#$%&*()?',"-_=+[]{}<>" ,"/\\:;.,'\"`~",'€£^|éèêàùç']
        for r,letters in enumerate(rows):
            self.keys.rowconfigure(r,weight=1)
            for c,char in enumerate(letters):
                self.keys.columnconfigure(c,weight=1,uniform='keys')
                value=char.upper() if self.upper else char
                tk.Button(self.keys,text=value,command=lambda v=value:self.insert(v),takefocus=0,font=('Sans',15),relief='flat',bg='white').grid(row=r,column=c,padx=2,pady=2,sticky='nsew')
    def close(self):
        w=self.window;self.window=None;self.target=None
        if w:
            try:w.grab_release();w.destroy()
            except tk.TclError:pass
        try:
            if self.previous_grab and self.previous_grab.winfo_exists():self.previous_grab.grab_set();self.previous_grab.focus_set()
            else:self.root.focus_set()
        except tk.TclError:pass
        self.previous_grab=None
