# Vérification 0.3

- Syntaxe Python : vérifiée.
- 15 tests automatisés réussis : 7 sur le domaine local et la session, 8 sur le client REST et l’échec de configuration.
- Le client est testé avec réponses simulées : pagination de 101 projets, listes vides, route de tâches, erreurs HTTP et réseau, JSON invalide, pagination incohérente, refus des redirections, HTTPS obligatoire, absence de clé dans les URL et absence d’écriture de configuration après échec.
- Les requêtes sont limitées à GET. Aucune donnée Dolibarr n’a été modifiée pendant la préparation.
- Routes et pagination fondées sur le code officiel Dolibarr 22.0.3 examiné précédemment. Aucun test authentifié n’a été effectué contre bcell.energy : la clé API n’est pas disponible dans cet environnement.
- L’affichage et les interactions sur Raspberry Pi/VNC restent à vérifier sur votre appareil. Pas d’essai matériel de l’écran tactile ni de tests/calibrage d’appareils.

Commande : `python3 -m unittest discover -v`
