# AtelierBorne Raspberry Pi — version 0.3

Application native Python/Tk pour Debian ARM64. Connexion locale obligatoire, puis deux modes distincts : démonstration, ou lecture des projets/tâches de Dolibarr. Le premier essai réel sur votre serveur nécessite votre clé API, saisie sur le Pi.

## Mettre à jour

Fermez l’application. Téléchargez le nouveau ZIP sur le Pi et placez-le dans le dossier personnel avec le nom `AtelierBorne_RaspberryPi.zip`, puis depuis un terminal ouvert DANS VNC :

```sh
cd ~
unzip -o AtelierBorne_RaspberryPi.zip
cd ~/AtelierBorne_RaspberryPi
python3 configurer_dolibarr.py
```

Le script utilise déjà `https://bcell.energy/dolibarr/`. Collez la clé API à l’invite, puis Entrée. Rien ne s’affiche pendant la saisie. La clé est enregistrée uniquement après une lecture réussie de la liste des projets ; en cas d’échec, la configuration précédente reste intacte.

Quand le script indique « Connexion réussie », lancez :

```sh
bash lancer.sh
```

Aucune nouvelle dépendance n’est nécessaire depuis la version précédente. Pour une première installation : `sudo apt update` puis `sudo apt install python3 python3-tk unzip`.

## Préparer le compte dans Dolibarr

Dans votre Dolibarr, avec un administrateur :

1. Vérifiez que le module API REST est activé.
2. Préparez un utilisateur interne dédié à la borne, non administrateur, et accordez-lui les droits de lecture des projets et tâches nécessaires. Vérifiez son accès aux projets privés et les restrictions aux tiers/commerciaux.
3. Sur sa fiche, définissez sa clé API. Copiez-la dans le terminal du Pi à la demande du script, sans l’envoyer dans la conversation.
4. Si besoin, inspectez les opérations disponibles dans `https://bcell.energy/dolibarr/api/index.php/explorer` avec cette clé.

Tous les opérateurs locaux utilisent pour le moment le même compte API en lecture. Ce n’est pas encore une connexion Dolibarr personnelle par salarié.

## Utilisation en mode Dolibarr

- La connexion locale est obligatoire avant tout accès aux onglets.
- L’en-tête indique « DOLIBARR · lecture seule ».
- Projets / Tâches affiche la liste des projets accessibles au compte API. Cliquez Voir les tâches pour lire les tâches et leur progression.
- Actualiser relit le serveur. Les requêtes réseau s’exécutent en arrière-plan ; un changement d’onglet ou une déconnexion empêche une réponse tardive de réafficher l’ancien écran.
- Une erreur réseau ou de permissions s’affiche explicitement. Elle n’est jamais remplacée par une liste vide ou des exemples fictifs.
- Vacances et Stocks sont en attente de raccordement dans ce mode. Aucun solde fictif n’est affiché à la place d’un solde réel.
- Tests / Pré-configuration / Calibrage restent des emplacements non connectés.

Seules des requêtes GET sont utilisées. Il n’y a aucune création, modification ou suppression dans Dolibarr. Les affectations de tâches, leurs modifications et les congés seront raccordés ensuite.

## Comptes locaux et plein écran

Comptes initiaux : Miora, Hery, Lova ; mot de passe `123456`. Pour personnaliser les comptes :

```sh
cd ~/AtelierBorne_RaspberryPi
cp -n comptes_exemple.py comptes_locaux.py
nano comptes_locaux.py
```

Modifiez le dictionnaire COMPTES, enregistrez et relancez. Ce fichier local n’est pas fourni dans le ZIP, donc les mises à jour le préservent. Les mots de passe sont en clair localement selon le choix du prototype. Déconnectez-vous après usage de la borne partagée. Le raccordement individuel aux identifiants Dolibarr reste à réaliser.

Échap : mode fenêtre. F11 : plein écran. Ctrl+Maj+Q : quitter (Ctrl, pas Cmd sur le Mac). `bash lancer.sh --windowed` démarre en fenêtre. Le clavier du Mac sert aux saisies ; le clavier virtuel tactile reste à intégrer. Le mode plein écran n’est pas un verrouillage du système.

## Démonstration et données précédentes

Sans fichier de configuration Dolibarr, le programme démarre en démonstration après connexion. Pour lancer volontairement la démonstration après configuration :

```sh
bash ~/AtelierBorne_RaspberryPi/lancer.sh --demo
```

L’en-tête distingue ce mode. Il conserve les quatre onglets précédents, la prise des tâches locales, les demandes visibles dans « Mes demandes » et les mouvements de stock fictifs. Le correctif de hauteur des onglets est inclus.

La base fictive reste dans `~/.local/share/atelierborne/demo.sqlite3` (ou sous XDG_DATA_HOME). Elle n’est ni supprimée ni envoyée à Dolibarr. En mode connecté, les données de projets/tâches sont lues en mémoire, sans import dans cette base.

La clé API est enregistrée dans `~/.config/atelierborne/dolibarr.json` (ou sous XDG_CONFIG_HOME), avec permissions 600. Ce fichier est distinct du programme, des comptes locaux et du ZIP. Ne l’incluez pas dans des captures ou fichiers envoyés pour dépannage.

## En cas d’erreur

- HTTP 401 : vérifiez la clé API.
- HTTP 403 : vérifiez les permissions du compte et son accès au projet.
- HTTP 404 : vérifiez le module API REST, le chemin Dolibarr et l’existence du projet.
- Zéro projet alors que des projets existent : la liste peut être limitée par les droits Projets, les restrictions commerciales/tiers ou l’entité active. Vérifiez avec le même compte dans Dolibarr et dans l’explorateur.
- Connexion impossible : vérifiez Internet et HTTPS sur le Pi, ainsi que l’heure du système pour les certificats.
- Réponse non JSON ou redirection : vérifier l’URL et les éventuelles protections/règles de redirection de l’hébergement. Le programme ne transfère jamais automatiquement la clé API vers une redirection.
- `no display name` : lancez l’application depuis le terminal dans VNC, pas depuis un terminal SSH simple ou celui du Mac.

Pour diagnostiquer, envoyez le message affiché par le script ou l’application, sans clé API ni fichier de configuration.

Le démarrage automatique n’est pas modifié. La résolution et les interactions restent à valider dans votre session VNC. Les paramètres d’accès au bureau restent ceux de votre Pi.
