# AtelierBorne — prototype Raspberry Pi / Linux 0.1

Application native Python/Tk, sans navigateur ni serveur web local. Cible : Raspberry Pi 4, Debian 13 ARM64, session graphique accessible par VNC. Aucun besoin de réinstaller le système ou de posséder déjà l’écran tactile.

**Démonstration uniquement. Aucune connexion à Dolibarr, aucun changement dans les stocks réels, aucune commande envoyée à un appareil.**

## Installer et tester via VNC

1. Ouvrez le bureau du Pi depuis votre Mac avec VNC.
2. Transférez `AtelierBorne_RaspberryPi.zip` dans votre dossier personnel sur le Pi. Vous pouvez aussi le télécharger avec le navigateur ouvert DANS VNC. Le fichier doit être dans `/home/VOTRE_UTILISATEUR/`, pas seulement dans Téléchargements sur le Mac.
3. Ouvrez un terminal **dans le bureau du Pi**, puis exécutez :

```sh
sudo apt update
sudo apt install python3 python3-tk unzip
cd ~
unzip AtelierBorne_RaspberryPi.zip
cd ~/AtelierBorne_RaspberryPi
bash lancer.sh
```

Seule l’installation des paquets demande `sudo`. Lancez l’application avec votre utilisateur habituel.

L’application démarre en plein écran. Échap revient en fenêtre ; F11 bascule le plein écran ; Ctrl+Maj+Q quitte. Sur le clavier du Mac, utilisez bien Ctrl (pas Cmd). En mode fenêtre, la croix permet aussi de quitter. Pour démarrer directement en fenêtre :

```sh
bash ~/AtelierBorne_RaspberryPi/lancer.sh --windowed
```

Le plein écran masque la décoration de la fenêtre principale. Ce prototype n’est pas un kiosque verrouillé : les raccourcis et le bureau restent accessibles. Les formulaires sont des fenêtres natives avec un bouton Fermer.

## Essai rapide

- Projets / Tâches : choisissez une tâche « À prendre », cliquez Prendre. Identité fictive : Miora, Hery ou Lova ; code **123456**. Retrouvez-la dans Prises en charge, puis Démarrer et Terminer avec la même identité.
- Vacances : consultez les absences fictives et déposez une demande. Les dates sont au format AAAA-MM-JJ. Les demandes restent « En attente » ; aucun workflow d’approbation ni compteur légal de congés n’est implémenté.
- Stocks : choisissez Atelier ou Magasin, puis Modifier. Un motif est obligatoire. Inventaire remplace le total par la quantité comptée. Pour les articles sérialisés : une unité par mouvement ; chaque numéro est unique dans ce registre local, même après sortie. Les retours et transferts ne sont pas encore implémentés.
- Tests + Pré-configuration calibrage : trois rubriques présentes, explicitement non connectées. Aucun résultat de mesure simulé n’est présenté comme réel.
- Quittez puis relancez : les modifications de démonstration sont conservées.

Le clavier du Mac sert à saisir codes, dates et motifs. Le clavier virtuel tactile et les essais sur l’écran final restent à réaliser. Les deux rangées d’onglets conviennent aux petites résolutions ; pour le test VNC, utilisez si possible 1024 × 768 ou davantage.

## Données locales

Base SQLite : `~/.local/share/atelierborne/demo.sqlite3`, ou `$XDG_DATA_HOME/atelierborne/demo.sqlite3` si cette variable est définie. Elle contient les tâches, mouvements, numéros de série et demandes fictives. Chaque Pi possède ses propres données de démonstration : les écrans ne se synchronisent pas encore.

Le code de test partagé n’est pas un mécanisme d’authentification de production. Fermez les formulaires personnels après usage. Ne saisissez pas de données réelles de salariés dans cette démonstration.

## Démarrage automatique

Commencez par valider le lancement manuel dans VNC. Le démarrage automatique dépend du bureau et du type de serveur VNC : session existante ou bureau virtuel. Il sera configuré une fois ce test réussi ; aucun fichier de démarrage, réglage VNC ni connexion automatique n’est modifié par ce paquet. Le système Debian démarre normalement, puis l’application s’exécute dans sa session graphique : ce ZIP n’est pas une image de carte SD.

Pour identifier le bureau depuis le terminal VNC :

```sh
printf 'Bureau : %s\nSession : %s\nAffichage : %s\n' "$XDG_CURRENT_DESKTOP" "$XDG_SESSION_TYPE" "$DISPLAY"
```

Ne forcez pas `DISPLAY=:0` : une session VNC virtuelle peut utiliser un autre affichage.

## En cas de problème

- `No module named tkinter` : réexécutez `sudo apt install python3-tk`.
- `no display name` / `couldn't connect to display` : utilisez un terminal ouvert DANS VNC, avec le même utilisateur. Le terminal du Mac ou une connexion SSH simple n’a pas accès automatiquement à cet affichage.
- Session Wayland sans affichage X disponible : Tk exige X11 ou XWayland. Relevez les variables ci-dessus avant de modifier la session ; le paquet ne reconfigure pas le bureau.
- Fenêtre trop grande : augmentez la résolution du bureau virtuel VNC, ou utilisez le mode fenêtre pour le premier essai.
- Pour demander de l’aide, transmettez l’erreur complète et le résultat des trois variables ci-dessus, sans secrets.

## Vérification et limites

Les tests de logique se lancent avec `python3 -m unittest -v test_app.py`. Ils couvrent la prise de tâches, le propriétaire, les quantités, l’inventaire périmé, les numéros de série, les dates et la persistance. Voir VERIFICATION.md pour la validation effectuée avant livraison. Le premier essai réel sur Raspberry Pi et VNC reste à effectuer chez vous.

Prochaine étape après validation visuelle : démarrage automatique adapté au bureau, puis API Dolibarr HTTPS et permissions par opérateur. Les tests/calibrages nécessitent les références exactes du matériel et les procédures validées avant toute intégration.
