# Prochaine étape : Dolibarr 22.0.3 sur OVH

La version 0.3 ajoute la lecture des projets et tâches, configurée pour https://bcell.energy/dolibarr/. La clé API est saisie exclusivement sur le Pi via configurer_dolibarr.py. Aucun secret n’est inclus dans le ZIP. Les demandes de congés et les soldes ne sont pas encore raccordés. Le propriétaire confirme que les soldes sont déjà renseignés : Dolibarr restera leur source de référence.

## Architecture prévue

Application native du Pi → HTTPS → API REST de Dolibarr sur OVH. Aucune ouverture de port entrant sur le Pi n’est nécessaire. Plusieurs bornes partageront ensuite la même source de données Dolibarr.

Les mots de passe locaux ouvrent une session sur la borne. Une clé API Dolibarr est une identité serveur distincte : conserver cette distinction et associer chaque opérateur local à son identifiant utilisateur Dolibarr. Avec une clé commune, les opérations peuvent être attribuées au compte technique ; pour une attribution native par salarié, prévoir une clé par utilisateur ou un module serveur qui journalise explicitement l’opérateur et applique ses droits.

## Lecture des projets et tâches — implémentée, à tester sur votre instance

1. Activer API REST et vérifier le module Projets.
2. Créer un utilisateur interne dédié, non administrateur, avec les droits de lecture nécessaires et l’accès aux projets concernés (notamment projets privés).
3. Définir sa clé API et la conserver dans un fichier local au Pi, exclu des archives distribuées. La clé ne doit pas être envoyée dans la conversation.
4. Ouvrir `https://VOTRE_BASE_DOLIBARR/api/index.php/explorer` et vérifier les routes exposées avec ce compte.
5. Tester `GET /projects`, puis `GET /projects/{id}/tasks`. Les appels utilisent l’en-tête `DOLAPIKEY`. Prévoir la pagination des projets.
6. Le mode « DOLIBARR · lecture seule » est disponible, séparé de la démonstration, avec heure de lecture et erreur explicite en cas de coupure. Les réponses ne sont pas remplacées par les exemples si le réseau tombe.

Les routes projets ci-dessus ont été vérifiées dans le fichier `htdocs/projet/class/api_projects.class.php` du tag officiel 22.0.3. Les droits doivent également être testés sur votre propre instance.

## Congés et soldes

Le dossier officiel `htdocs/holiday/class` du tag 22.0.3 contient `holiday.class.php`, sans classe REST `api_holidays.class.php`. Ne pas présumer que les API des versions plus récentes existent sur votre installation. Vérifier l’explorateur pour les éventuelles extensions déjà installées.

Si les services nécessaires manquent, ajouter un petit module Dolibarr dans `custom` exposant, avec contrôle des permissions :

- les demandes du salarié connecté et leurs statuts ;
- ses soldes par type de congé ;
- le planning d’absences autorisé pour la borne ;
- ensuite, la création et la soumission au responsable de validation.

Réutiliser les classes et règles de gestion de Dolibarr. Ne pas recalculer le solde en soustrayant simplement des jours calendaires : les types, jours ouvrés, demi-journées et états des demandes doivent rester cohérents avec la configuration serveur. La borne ne doit pas écrire directement dans la base MySQL.

## Écritures ensuite

Après validation de la lecture : prise des tâches avec contrôle des prises simultanées entre bornes, progression, création/soumission de congés et mouvements de stock. Un « pris par » local n’est pas encore une affectation Dolibarr : définir la correspondance avec les contacts/affectations de tâches disponibles sur l’instance. Prévoir une protection contre les doubles envois après coupure réseau.

## Informations nécessaires

- URL connue : https://bcell.energy/dolibarr/ ;
- liste des rubriques visibles dans l’explorateur API ;
- noms des comptes locaux et identifiants numériques utilisateurs Dolibarr correspondants ;
- types de congés utilisés (les soldes sont déjà tenus à jour, confirmé).

## Sources vérifiées

- https://wiki.dolibarr.org/index.php/Module_Web_Services_REST
- https://github.com/Dolibarr/dolibarr/blob/22.0.3/htdocs/projet/class/api_projects.class.php
- https://github.com/Dolibarr/dolibarr/tree/22.0.3/htdocs/holiday/class
