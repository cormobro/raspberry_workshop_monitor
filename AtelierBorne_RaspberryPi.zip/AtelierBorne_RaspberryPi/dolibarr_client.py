"""Client Dolibarr 22 : lecture seule, bibliothèque standard Python."""
import json
import os
from pathlib import Path
import socket
import ssl
from urllib import request, error, parse

BASE_URL = 'https://bcell.energy/dolibarr/'
MAX_BYTES = 8 * 1024 * 1024
class ApiError(Exception): pass

class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ApiError('Redirection HTTP refusée. Vérifiez l’URL de base Dolibarr.')

def config_path():
    return Path(os.environ.get('XDG_CONFIG_HOME',Path.home()/'.config'))/'atelierborne'/'dolibarr.json'

def load_client():
    path=config_path()
    if not path.exists():return None
    try:
        config=json.loads(path.read_text())
        return Client(config['base_url'],config['api_key'])
    except (OSError,ValueError,KeyError,TypeError):
        raise ApiError('Configuration Dolibarr invalide. Relancez configurer_dolibarr.py.')

class Client:
    def __init__(self, base_url, api_key, opener=None):
        if not isinstance(base_url,str) or not isinstance(api_key,str):raise ApiError('Configuration invalide.')
        parts=parse.urlsplit(base_url)
        if parts.scheme!='https' or not parts.hostname or parts.username or parts.password or parts.query or parts.fragment:
            raise ApiError('Une URL HTTPS de base, sans identifiants ni paramètres, est requise.')
        if not api_key.strip() or '\n' in api_key or '\r' in api_key:raise ApiError('Clé API invalide.')
        self.base_url=base_url.rstrip('/')+'/'
        self.api_url=self.base_url+'api/index.php/'
        self.key=api_key.strip()
        self.opener=opener or request.build_opener(NoRedirect(),request.HTTPSHandler(context=ssl.create_default_context()))
    def _get(self, route, params=None):
        url=self.api_url+route
        if params:url+='?'+parse.urlencode(params)
        req=request.Request(url,headers={'DOLAPIKEY':self.key,'Accept':'application/json'},method='GET')
        try:
            with self.opener.open(req,timeout=15) as response:
                data=response.read(MAX_BYTES+1)
            if len(data)>MAX_BYTES:raise ApiError('Réponse trop volumineuse. Réduisez la taille des données côté serveur.')
            result=json.loads(data)
        except error.HTTPError as e:
            messages={401:'Clé API absente ou refusée.',403:'Accès refusé : vérifiez les droits et l’accès à ce projet.',404:'Service introuvable : vérifiez le module API REST, le chemin et la ressource.',429:'Trop de requêtes : réessayez plus tard.'}
            raise ApiError(f'HTTP {e.code} — '+messages.get(e.code,'Le serveur Dolibarr a renvoyé une erreur.')) from None
        except (error.URLError, socket.timeout, TimeoutError,ssl.SSLError,OSError):
            raise ApiError('Connexion impossible : vérifiez Internet, le certificat HTTPS et la disponibilité de Dolibarr.') from None
        except (ValueError,UnicodeError):
            raise ApiError('La réponse n’est pas du JSON valide. Vérifiez l’URL, l’API REST et les éventuelles protections OVH.') from None
        if not isinstance(result,list) or any(not isinstance(item,dict) for item in result):
            raise ApiError('Format API inattendu : une liste d’objets était attendue.')
        return result
    def projects_page(self,page=0,limit=100):
        return self._get('projects',{'sortfield':'t.rowid','sortorder':'ASC','limit':limit,'page':page})
    def projects(self):
        projects=[];seen=set()
        for page in range(1000):
            batch=self.projects_page(page)
            for item in batch:
                ident=str(item.get('id',''))
                if not ident.isdecimal() or int(ident)<=0:raise ApiError('Identifiant de projet invalide dans la réponse.')
                if ident in seen:raise ApiError('Pagination incohérente. Actualisez la liste des projets.')
                seen.add(ident);projects.append(item)
            if len(batch)<100:return projects
        raise ApiError('Limite de pagination atteinte : liste non affichée pour éviter une vue incomplète.')
    def tasks(self,project_id):
        ident=str(project_id)
        if not ident.isdecimal() or int(ident)<=0:raise ApiError('Identifiant de projet invalide.')
        return self._get('projects/'+ident+'/tasks')
