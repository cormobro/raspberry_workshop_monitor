#!/usr/bin/env python3
"""AtelierBorne — prototype Linux natif, exclusivement en démonstration."""
import argparse
import datetime as dt
import os
from pathlib import Path
import sqlite3
import tkinter as tk
from tkinter import ttk

BLUE = '#215bc5'
BG = '#f4f6fa'
PEOPLE = ('Miora', 'Hery', 'Lova')

class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY,title TEXT,project TEXT,owner TEXT,progress INTEGER);
        CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT,serial INTEGER);
        CREATE TABLE IF NOT EXISTS stock(product TEXT,warehouse TEXT,qty INTEGER CHECK(qty>=0),PRIMARY KEY(product,warehouse));
        CREATE TABLE IF NOT EXISTS serials(code TEXT PRIMARY KEY,product TEXT,warehouse TEXT,active INTEGER);
        CREATE TABLE IF NOT EXISTS leaves(id INTEGER PRIMARY KEY,person TEXT,start TEXT,end TEXT,status TEXT);
        CREATE TABLE IF NOT EXISTS journal(id INTEGER PRIMARY KEY,at TEXT,person TEXT,action TEXT);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
        ''')
        if not self.db.execute("SELECT 1 FROM meta WHERE key='seed'").fetchone():
            with self.db:
                self.db.executemany('INSERT INTO tasks VALUES(?,?,?,?,?)', [(1,'Préparer les kits du lot suivant','Assemblage',None,0),(2,'Compléter les fiches de contrôle','Qualité',None,0),(3,'Vérifier la réception des boîtiers','Stock','Hery',40)])
                self.db.executemany('INSERT INTO products VALUES(?,?,?)', [('CELL-314','Cellules LFP 314 Ah',0),('BMS-16S','BMS 16S',1),('BAT-LV','Batterie LV assemblée',1),('BOX-LV','Boîtiers LV',0)])
                for product, a, m in [('CELL-314',64,128),('BMS-16S',2,0),('BAT-LV',1,0),('BOX-LV',12,0)]:
                    self.db.executemany('INSERT INTO stock VALUES(?,?,?)',[(product,'Atelier',a),(product,'Magasin',m)])
                self.db.executemany('INSERT INTO serials VALUES(?,?,?,1)', [('BMS-00041','BMS-16S','Atelier'),('BMS-00042','BMS-16S','Atelier'),('BAT-00108','BAT-LV','Atelier')])
                today = dt.date.today()
                for person, offset in [('Miora',7),('Lova',15)]:
                    self.db.execute('INSERT INTO leaves(person,start,end,status) VALUES(?,?,?,?)',(person,str(today+dt.timedelta(days=offset)),str(today+dt.timedelta(days=offset+2)),'Validée (démo)'))
                self.db.execute("INSERT INTO meta VALUES('seed','1')")
    def rows(self, sql, args=()):
        return self.db.execute(sql,args).fetchall()
    def log(self, person, action):
        self.db.execute('INSERT INTO journal(at,person,action) VALUES(?,?,?)',(dt.datetime.now().isoformat(timespec='seconds'),person,action))
    def task(self, ident, action, person):
        if person not in PEOPLE or action not in ('Prendre','Démarrer','Terminer'): raise ValueError('Action ou opérateur inconnu.')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.rows('SELECT * FROM tasks WHERE id=?',(ident,))[0]
            if action == 'Prendre':
                if row['owner']: raise ValueError('Cette tâche est déjà prise.')
                self.db.execute('UPDATE tasks SET owner=? WHERE id=?',(person,ident))
            else:
                if row['owner'] != person: raise ValueError('Seule la personne qui a pris la tâche peut la modifier.')
                if row['progress'] == 100: raise ValueError('Cette tâche est déjà terminée.')
                progress = 1 if action == 'Démarrer' else 100
                self.db.execute('UPDATE tasks SET progress=? WHERE id=?',(progress,ident))
            self.log(person,f'Tâche {ident} : {action}')
    def movement(self, product, warehouse, mode, quantity, serial, reason, person, expected):
        if not reason.strip(): raise ValueError('Indiquez un motif.')
        try: quantity = int(quantity)
        except (ValueError, TypeError): raise ValueError('La quantité doit être un nombre entier.')
        if quantity < 0 or (mode != 'Inventaire' and quantity == 0): raise ValueError('Quantité incorrecte.')
        serial = serial.strip().upper()
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            p = self.rows('SELECT * FROM products WHERE id=?',(product,))
            stocks = self.rows('SELECT qty FROM stock WHERE product=? AND warehouse=?',(product,warehouse))
            if not p or not stocks: raise ValueError('Produit ou entrepôt inconnu.')
            old = stocks[0]['qty']
            if mode not in ('Entrée','Sortie','Inventaire'): raise ValueError('Mouvement inconnu.')
            if p[0]['serial']:
                if mode == 'Inventaire': raise ValueError('Pour un produit sérialisé, utilisez une entrée ou une sortie par numéro.')
                if quantity != 1 or not serial: raise ValueError('Un numéro de série et une quantité de 1 sont obligatoires.')
                if len(serial)>100: raise ValueError('Numéro trop long (100 caractères maximum).')
                existing = self.rows('SELECT * FROM serials WHERE code=?',(serial,))
                if mode == 'Entrée':
                    if existing: raise ValueError('Ce numéro existe déjà dans le registre, même après une sortie.')
                    self.db.execute('INSERT INTO serials VALUES(?,?,?,1)',(serial,product,warehouse))
                else:
                    if not existing or not existing[0]['active'] or existing[0]['product'] != product or existing[0]['warehouse'] != warehouse:
                        raise ValueError('Ce numéro ne se trouve pas dans ce stock.')
                    self.db.execute('UPDATE serials SET active=0 WHERE code=?',(serial,))
            if mode == 'Inventaire' and old != expected: raise ValueError('Le stock a changé. Fermez puis rouvrez ce formulaire.')
            new = quantity if mode == 'Inventaire' else old + (quantity if mode == 'Entrée' else -quantity)
            if new < 0: raise ValueError('Stock insuffisant.')
            self.db.execute('UPDATE stock SET qty=? WHERE product=? AND warehouse=?',(new,product,warehouse))
            self.log(person,f'{mode} {product} / {warehouse} : {old} → {new}; série {serial or "—"}; {reason.strip()}')
    def leave(self, person, start, end):
        try: a,b = dt.date.fromisoformat(start),dt.date.fromisoformat(end)
        except ValueError: raise ValueError('Dates invalides. Format : AAAA-MM-JJ.')
        if b<a: raise ValueError('La fin doit être après le début.')
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            if self.rows('SELECT 1 FROM leaves WHERE person=? AND start<=? AND end>=?',(person,end,start)):
                raise ValueError('Ces dates recouvrent une demande existante.')
            self.db.execute('INSERT INTO leaves(person,start,end,status) VALUES(?,?,?,?)',(person,start,end,'En attente (démo)'))
            self.log(person,f'Demande de vacances : {start} au {end}')

class App:
    def __init__(self, root, store, fullscreen=True):
        self.root, self.store = root, store
        self.tab = 1
        self.filter = 'À prendre'
        self.warehouse = 'Atelier'
        root.title('AtelierBorne — démonstration')
        root.geometry('1024x700')
        root.configure(bg=BG)
        root.option_add('*Font', 'Sans 13')
        root.attributes('-fullscreen', fullscreen)
        root.bind('<Escape>', lambda e: root.attributes('-fullscreen',False))
        root.bind('<F11>', lambda e: root.attributes('-fullscreen',not root.attributes('-fullscreen')))
        root.bind('<Control-Shift-Q>',lambda e: root.destroy())
        root.bind('<Control-Shift-q>',lambda e: root.destroy())
        header = tk.Frame(root,bg='white',padx=18,pady=10); header.pack(fill='x')
        tk.Label(header,text='ATELIER',font=('Sans',20,'bold'),bg='white').pack(side='left')
        tk.Label(header,text='DÉMO · aucune connexion à Dolibarr',bg='white',fg='#8a4a00').pack(side='right')
        nav = tk.Frame(root,bg=BG,padx=8,pady=8); nav.pack(fill='x')
        self.tabs=[]
        for i,title in enumerate(('Vacances','Projets / Tâches','Stocks','Tests +\nPré-configuration calibrage')):
            b=tk.Button(nav,text=title,command=lambda i=i:self.show(i),height=2,wraplength=220,relief='flat')
            b.grid(row=i//2,column=i%2,sticky='nsew',padx=4,pady=3)
            self.tabs.append(b)
        nav.columnconfigure((0,1),weight=1)
        self.body=tk.Frame(root,bg=BG,padx=18,pady=8); self.body.pack(fill='both',expand=True)
        tk.Label(root,text='Essai VNC : Échap = mode fenêtre · F11 = plein écran · Ctrl+Maj+Q = quitter',bg=BG,fg='#5a6577',font=('Sans',10)).pack(pady=5)
        self.show(1)
    def button(self,parent,text,command):
        b=tk.Button(parent,text=text,command=command,bg=BLUE,fg='white',activebackground='#174393',activeforeground='white',relief='flat',padx=16,pady=10)
        return b
    def label(self,parent,text,large=False):
        w=tk.Label(parent,text=text,bg=parent.cget('bg'),anchor='w',justify='left',wraplength=760,font=('Sans',18,'bold') if large else ('Sans',13))
        w.pack(fill='x',pady=6); return w
    def listing(self):
        frame=tk.Frame(self.body,bg=BG); frame.pack(fill='both',expand=True,pady=8)
        canvas=tk.Canvas(frame,bg=BG,highlightthickness=0)
        bar=ttk.Scrollbar(frame,orient='vertical',command=canvas.yview)
        bar.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=bar.set)
        content=tk.Frame(canvas,bg=BG); item=canvas.create_window((0,0),window=content,anchor='nw')
        content.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        return content
    def card(self,parent):
        f=tk.Frame(parent,bg='white',padx=14,pady=10);f.pack(fill='x',pady=5);return f
    def dialog(self,title):
        w=tk.Toplevel(self.root); w.title(title); w.transient(self.root); w.configure(bg='white',padx=20,pady=15)
        w.geometry(f'620x470+{max(0,self.root.winfo_rootx()+30)}+{max(0,self.root.winfo_rooty()+30)}')
        w.grab_set(); w.bind('<Escape>',lambda e:w.destroy())
        self.label(w,title,True)
        self.button(w,'Fermer',w.destroy).pack(side='bottom',anchor='e',pady=5)
        return w
    def notify(self,title,text):
        w=self.dialog(title);self.label(w,text);return w
    def authenticated(self,callback):
        w=self.dialog('Identification de démonstration')
        self.label(w,'Choisissez un opérateur fictif. Code de test : 123456.\nCette identification ne sécurise pas une installation réelle.')
        person=ttk.Combobox(w,values=PEOPLE,state='readonly');person.set(PEOPLE[0]);person.pack(fill='x',pady=10)
        pin=tk.Entry(w,show='•');pin.pack(fill='x',pady=10);pin.focus_set()
        status=self.label(w,'')
        def go():
            if pin.get() != '123456':status.config(text='Code incorrect.');return
            value=person.get();w.destroy();callback(value)
        self.button(w,'Continuer',go).pack(pady=10);pin.bind('<Return>',lambda e:go())
    def perform(self,call,dialog=None):
        try:call()
        except (ValueError,sqlite3.Error) as e:self.notify('Action impossible',str(e));return False
        if dialog:dialog.destroy()
        self.show(self.tab);return True
    def show(self,index):
        self.tab=index
        for i,b in enumerate(self.tabs):b.config(bg=BLUE if i==index else 'white',fg='white' if i==index else '#172338')
        for w in self.body.winfo_children():w.destroy()
        (self.vacances,self.tasks,self.stocks,self.technical)[index]()
    def tasks(self):
        self.label(self.body,'Projets / Tâches',True)
        line=tk.Frame(self.body,bg=BG);line.pack(fill='x')
        for value in ('À prendre','Prises en charge','Terminées'):
            def select(v=value):self.filter=v;self.show(1)
            self.button(line,('✓ ' if self.filter==value else '')+value,select).pack(side='left',padx=3)
        area=self.listing();count=0
        for r in self.store.rows('SELECT * FROM tasks ORDER BY id'):
            category='Terminées' if r['progress']==100 else 'Prises en charge' if r['owner'] else 'À prendre'
            if category!=self.filter:continue
            count+=1;f=self.card(area);self.label(f,r['title'],True)
            self.label(f,f"{r['project']} · {r['owner'] or 'Non attribuée'} · {r['progress']} %")
            if r['progress']<100:
                action='Prendre' if not r['owner'] else 'Démarrer' if r['progress']==0 else 'Terminer'
                self.button(f,action,lambda r=r,a=action:self.authenticated(lambda p:self.perform(lambda:self.store.task(r['id'],a,p)))).pack(anchor='e')
        if not count:self.label(area,'Aucune tâche dans cette liste.')
    def vacances(self):
        self.label(self.body,'Vacances',True)
        self.button(self.body,'Mes demandes / demander des vacances',lambda:self.authenticated(self.leave_form)).pack(anchor='w')
        area=self.listing()
        for r in self.store.rows("SELECT * FROM leaves WHERE status='Validée (démo)' ORDER BY start"):
            f=self.card(area);self.label(f,r['person'],True);self.label(f,f"Du {r['start']} au {r['end']} · {r['status']}")
    def leave_form(self,person):
        w=self.dialog(f'Vacances · {person}');w.geometry('620x580')
        for r in self.store.rows('SELECT * FROM leaves WHERE person=? ORDER BY start',(person,)):
            self.label(w,f"{r['start']} → {r['end']} · {r['status']}")
        self.label(w,'Nouvelle demande — dates au format AAAA-MM-JJ')
        entries=[]
        for name in ('Début','Fin'):
            self.label(w,name);e=tk.Entry(w);e.insert(0,str(dt.date.today()));e.pack(fill='x');entries.append(e)
        self.button(w,'Enregistrer la demande (démo)',lambda:self.perform(lambda:self.store.leave(person,entries[0].get(),entries[1].get()),w)).pack(pady=12)
    def stocks(self):
        line=tk.Frame(self.body,bg=BG);line.pack(fill='x')
        self.label(line,'Stocks',True)
        warehouses=ttk.Combobox(line,values=('Atelier','Magasin'),state='readonly');warehouses.set(self.warehouse);warehouses.pack(anchor='w')
        def changed(e):self.warehouse=warehouses.get();self.show(2)
        warehouses.bind('<<ComboboxSelected>>',changed)
        area=self.listing()
        for r in self.store.rows('SELECT p.*,s.qty FROM products p JOIN stock s ON s.product=p.id WHERE s.warehouse=? ORDER BY p.id',(self.warehouse,)):
            f=self.card(area);self.label(f,f"{r['name']} : {r['qty']}",True)
            self.label(f,r['id']+(' · numéros de série uniques' if r['serial'] else ' · suivi en quantité'))
            buttons=tk.Frame(f,bg='white');buttons.pack(fill='x')
            self.button(buttons,'Modifier',lambda r=r:self.authenticated(lambda p:self.stock_form(r,p))).pack(side='right')
            if r['serial']:
                self.button(buttons,'Numéros de série',lambda r=r:self.serial_list(r)).pack(side='left')
    def serial_list(self,r):
        rows=self.store.rows('SELECT code FROM serials WHERE product=? AND warehouse=? AND active=1 ORDER BY code',(r['id'],self.warehouse))
        w=self.dialog('Numéros présents · '+r['id']);box=tk.Text(w,height=10,font=('Sans',15));box.pack(fill='both',expand=True)
        box.insert('1.0','\n'.join(x['code'] for x in rows) or 'Aucun numéro présent.');box.config(state='disabled')
    def stock_form(self,r,person):
        warehouse=self.warehouse
        w=self.dialog(f"{r['id']} · {warehouse} · {person}");w.geometry('620x590')
        self.label(w,f"Stock affiché : {r['qty']} · modification locale de démonstration")
        mode=ttk.Combobox(w,values=('Entrée','Sortie') if r['serial'] else ('Entrée','Sortie','Inventaire'),state='readonly');mode.set('Entrée');mode.pack(fill='x',pady=8)
        self.label(w,'Quantité (Inventaire = quantité totale comptée)')
        qty=tk.Entry(w);qty.insert(0,'1');qty.pack(fill='x')
        if r['serial']:qty.config(state='readonly')
        self.label(w,'Numéro de série' if r['serial'] else 'Numéro de série : non requis')
        serial=tk.Entry(w);serial.pack(fill='x')
        if not r['serial']:serial.config(state='disabled')
        self.label(w,'Motif obligatoire');reason=tk.Entry(w);reason.pack(fill='x')
        self.button(w,'Enregistrer (démo)',lambda:self.perform(lambda:self.store.movement(r['id'],warehouse,mode.get(),qty.get(),serial.get(),reason.get(),person,r['qty']),w)).pack(pady=15)
    def technical(self):
        self.label(self.body,'Tests + Pré-configuration calibrage',True)
        self.label(self.body,'Emplacements prévus pour la future intégration des équipements.')
        area=self.listing()
        for title,description in [('Tests','Sélectionner à terme un appareil et une procédure validée.'),('Pré-configuration','Préparer à terme les paramètres autorisés pour un modèle.'),('Calibrage','À définir selon le matériel et la procédure du fabricant.')]:
            f=self.card(area);self.label(f,title,True);self.label(f,description)
            self.button(f,'État de l’intégration',lambda title=title:self.notify(title,'Non connecté.\nAucune mesure, aucun test ni réglage matériel ne sont exécutés dans ce prototype.')).pack(anchor='e')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--windowed',action='store_true');args=parser.parse_args()
    directory=Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'atelierborne'
    directory.mkdir(parents=True,exist_ok=True)
    store=Store(directory/'demo.sqlite3')
    try:root=tk.Tk()
    except tk.TclError as e:
        raise SystemExit('Impossible d’ouvrir la session graphique. Lancez ce programme depuis un terminal OUVERT DANS VNC.\n'+str(e))
    App(root,store,not args.windowed)
    try:root.mainloop()
    finally:store.db.close()
if __name__=='__main__':main()
