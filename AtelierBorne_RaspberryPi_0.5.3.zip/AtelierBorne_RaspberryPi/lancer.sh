#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! /usr/bin/python3 -c 'import tkinter' 2>/dev/null; then
  echo 'Installez les dépendances : sudo apt install python3 python3-tk'
  exit 1
fi
echo 'AtelierBorne Pi 0.5.3 - fabrication, suppression et clavier tactile'
exec /usr/bin/python3 app.py "$@"
