# Copiez ce fichier sous comptes_locaux.py pour personnaliser vos comptes.
# Ce fichier local ne sera pas fourni dans les mises à jour.
# Mots de passe locaux en clair, conformément au choix du prototype.
COMPTES = {
    "Miora": "123456",
    "Hery": "123456",
    "Lova": "123456",
}
